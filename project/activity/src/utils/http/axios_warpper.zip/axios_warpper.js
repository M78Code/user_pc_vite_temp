/*
 * @Author: success
 * @Date: 2020-08-04 17:13:55
 * @Description: 公共axios操作类http定义
 */
import axios from "axios";
import { uid } from 'quasar';
import pako_pb from "src/public/utils/custom_pb_pako.js";


import  init_window_env  from  "src/public/utils/window_env/window_env.js"
//获取当前 分组的 API 的 长度
function get_all_current_group_length() {
  // let key = this.DOMAIN_API;
  let key = "domain_api01";
  console.log("key = this.DOMAIN_API--", key);
  let gr = sessionStorage.getItem("gr");
  console.log('sessionStorage.getItem("gr")---', gr);
  // 返回默认值
  let ret = [];
  // 获取持久化数据
  let str = localStorage.getItem(key);
  console.log("获取持久化数据------", str);
  if (str) {
    try {
      // 字符串转json对象
      ret = JSON.parse(str);
      // 当是获取domain_api时
      if (_.isArray(ret)) {
        // 获取全局分组信息
        for (let i = 0; i < ret.length; i++) {
          // 获取分组信息
          const group = _.get(ret, `[${i}].group`);
          if (gr != group) {
            ret.splice(i, 1);
            i--;
          }
        }
      }
    } catch (error) {
      console.error(error);
    }
  }

  return  ret.length
}

// 计算  error_max 的值

 function compute_error_max(){

  let    len = get_all_current_group_length()
  if(len==0){
    len= 10
  }

  return len


}



// 解析判定 url

function  jie_xi_url(url_temp=''){

        //  截取 ?

      url_temp =url_temp.split("?")[0]
      //去除 ://
      if(url_temp.startsWith('://')){
        url_temp = url_temp.slice(3)
      }
      // 是完整的链接
      let is_full_url= (url_temp.startsWith('http://') || url_temp.startsWith('https://'))
      // 非常规业务逻辑 ，指定的完整url ，不走 baseurl
      let is_other_api = is_full_url &&( url_temp.includes('sdjfgsijmdkdhsa.gzxxty168.com') ||url_temp.includes('information-api.sportxxxwo8.com')   )
       // 为了兼容可能的错误  url_temp 带 http 开头 或者 不带   需要截取 纯粹的 pathname
      // 新的 url 片段
      let new_url_temp=url_temp
      // 是完整的链接 并且 是常规的业务逻辑
       if(is_full_url&&!is_other_api){
        new_url_temp = new URL(url_temp)['pathname']
       }
      return {
        is_full_url,
        is_other_api,
        new_url_temp
      }

}



class http {
  // http错误访问处理
  static err_count = {};
  // api错误信息收集接口
  static HTTP_ERROR_API = "https://sdjfgsijmdkdhsa.gzxxty168.com/api/client/adderror";
  // 用户配置收集接口
  static HTTP_PRO_INFO_API = "https://sdjfgsijmdkdhsa.gzxxty168.com/api/client/statistics";
  // 数据上报
  static HTTP_UPLOAD_API = "https://information-api.sportxxxwo8.com";
  // 最近的错误数组，用于分析上报
  static HTTP_ERROR_API_ERR_DATA = [];
  // 接口限流使用
  static limit_api = {};
  // 是否触发过限流接口-接口限流使用
  static limit_api_flg = false;
  // api访问数量(每分钟)
  static request_count = 0;
  // api访问数量使用的定时器
  static request_count_timer = null;
  // 显示失效弹出框使用的定时器
  static show_fail_alert_timer = null;
  // token api接口连续失效次数
  static token_invalid_api_count = 0;
  // token api接口连续失效用到的延时器
  static token_invalid_api_timer = 0;

  static openboxTimer = null;
/**
 * 初始化window.env
 * 这个方法 要在 http.init() 方法之前调用
 *
 */
 static init_window_env(){

  init_window_env()



 }

  /**
   * @Description:初始化网络配置信息
   * @Author success
   * @param:
   * @return:
   * @Date 2020/08/29 20:43:22
   */
  static init(){
    clearInterval(http.request_count_timer);
    http.request_count_timer = setInterval(() => {
      console.log('http.request_count='+http.request_count)
      if(window.wslog && window.wslog.sendMsg){
        window.wslog.sendMsg('HTTP-S:', { request_count: http.request_count});
      }
      http.request_count = 0;
    }, 60*1000);
    // 新逻辑这里只会有一个
    let api_domains = window.env.config.domain[window.env.config.current_env]

    // console.log(JSON.stringify(window.env))
    const env_project_name = window.env.config.FINAL_TARGET_PROJECT_NAME
    // 超时时间
    axios.defaults.timeout = 10000;

    let api_domain = api_domains[0];
    axios.defaults.baseURL = api_domain;
        axios.prototype.HTTP_ROOT_DOMAIN = api_domain;
    axios.prototype.WS_ROOT_DOMAIN = api_domain?api_domain.replace("http","ws"):'';

    if (env_project_name == 'yabo') {
      axios.interceptors.request.use(
        config => {
          // console.log(4444, config)
          // 自定义参数 说明  type  1 formdata 2 json 3 file   默认 json
          if (config.type == 1) {
            const formData = new FormData();
            let data = config.data || {};
            Object.keys(data).forEach(key => {
              formData.append(key, data[key]);
            });
            config.data = formData;
            config.headers["Content-Type"] =  "application/x-www-form-urlencoded; charset=UTF-8";
          } else if (config.type == 3) {
            config.headers["Content-Type"] = "multipart/form-data";
          }


          // config.headers["requestId"] = utils.get_request_id();

          // if (config.url.includes('/livechat') || config.url.includes('/user/getvipinfo')) {
          if (0) {
            config.headers["requestId"] = '1234567890'
          } else {
            config.headers["requestId"] = window.vue.$store.getters.get_user.token || sessionStorage.getItem('h5_token') ||"";
          }
          
          config.headers["lang"] = window.reset_lang || window.vue.lang || 'zh';
          let server_time = new Date().getTime();
          if(window.vue){
            try {
              server_time = server_time - window.vue.$store.getters.get_timestamp.local_time + window.vue.$store.getters.get_timestamp.remote_time;
            } catch (error) {console.log(error)}
          }
          config.headers["checkId"] = 'pc-'+config.headers["requestId"]+'-'+(uid().replace(/-/g, ""))+'-'+server_time;
          // window.wslog.sendMsg('HTTP-S:', config);
          config.time = new Date().getTime();
          http.request_count++;
          // config.url 后面是不带 ？的  会被 axios 解析掉参数放在其他地方
          if(sessionStorage.getItem('pb')){
            if(_.endsWith(config.url, 'PB')){
              config.url = config.url.substring(0,config.url.length-2);
            } else {
              if(config.url && config.url.indexOf('PB?') !=-1){
                config.url = config.url.replace('PB?','?');
              }
            }
          }
          console.log('config-------------',config);
          // 统计api访问数量
          return config;
        },
        // error => {
        //   // 设置出现网络中断页面
        //   if (window.vue && !window.vue.socket_status && !window.vue.no_network_show) {
        //     window.vue.no_network_show = true;
        //   }
        //   return Promise.reject(error);
        // }
      );
      // http响应拦截器
      axios.interceptors.response.use(
        res => {
          console.log('res.config.url------',res.config.url);
          let url_temp = _.get(res, 'config.url');

           // 解析url
          let jiexi_result = jie_xi_url(url_temp)
          // 后面非常规业务逻辑 所用axios 需要和常规的分开
          if(jiexi_result.is_other_api ){
             return res;
          }

          url_temp = jiexi_result.new_url_temp




                 // 响应成功关闭loading
          // window.wslog.sendMsg('HTTP-R:', res);


           // 常规的业务 的 url 是不带 http 前缀的 不是完整域名 ，其他的都是完整域名
           // 单独的 外层的一些逻辑 并不走这个 axios 实例，比如外层的OSS 内的 api 逻辑


          if (res.data.code == '0000000') {
            // token api接口连续失效次数初始化
            http.token_invalid_api_count = 0;
            // token api接口连续失效延时器初始化
            clearTimeout(http.token_invalid_api_timer);
            http.token_invalid_api_timer = 0;
            res.data.ts_http = new Date().getTime()-res.config.time;
            // 修正mst倒计时
            http.fix_mst(res);
            // 0000000-数据返回成功
            res.data.code = 200;
            http.limit_api[url_temp] = 1;
            if(url_temp && _.endsWith(url_temp, 'PB')){
              let data_temp = pako_pb.unzip_data(_.get(res, 'data.data'));
              if(data_temp){
                res.data.data = data_temp;
              }
            }
            // 登录失效的处理
          } else if (
            (res.data.code == "0401013" ||  (res.data.code == '0400500' && url_temp.includes("user/getUserInfo") ) ) &&
            !url_temp.includes("getSystemTime/currentTimeMillis")
          ) {
            // 连续累加token失效次数,当失效次数超过15秒时,弹出token失效框
            http.token_invalid_api_count++;
            if(!http.token_invalid_api_timer){
              console.log('启动延时器>>>>'+http.token_invalid_api_timer);
              clearTimeout(http.token_invalid_api_timer);
              http.token_invalid_api_timer = setTimeout(() => {
                console.log('启动延时器:http.token_invalid_api_count=',http.token_invalid_api_count);
                if(http.token_invalid_api_count){
                  // 设置登录无效
                  window.vue.$store.commit("set_is_invalid", true);
                  try {
                    // 强制弹token失效窗口
                    clearTimeout(http.show_fail_alert_timer);
                    http.show_fail_alert_timer = setTimeout(() => {
                      window.vue.show_fail_alert();
                    }, 500);
                  } catch (error) {
                    console.error(error)
                  }
                  if(window.ws){
                    window.ws.destroy(true);
                  }
                }
                clearTimeout(http.token_invalid_api_timer);
                http.token_invalid_api_timer = 0;
              }, 15000);
            }
          } else if (res.data.code == '0401038' && url_temp.indexOf("getSystemTime/currentTimeMillis") == -1) { // 用户接口限流
            window.limit_api_flg = true;
            if (env_project_name == 'yabo') {
              if(!http.limit_api[url_temp]){
                http.limit_api_flg = true;
                window.vue.$root.$emit('user_api_limited', {api:url_temp, type:'limited'});
                // if(window.ws){
                //   window.ws.destroy(true);
                // }
              }
            }
          }






          // 访问成功后清除之前的URL错误计数器
          if(http.err_count[url_temp]){
            http.err_count[url_temp] = 0;
          }
          if(window.httplog){
            window.httplog.push({url:url_temp})
          }
          return res;
        },
        error => {
          console.log("error.config-------------",error.config);

          if( !error || !error.config){
            return Promise.reject(error);
          }

          let  error_url= error.config.url


          // 解析url
          let jiexi_result = jie_xi_url(error_url)
          // 后面非常规业务逻辑 所用axios 需要和常规的分开
          if(jiexi_result.is_other_api ){
            return Promise.reject(error);
          }

          error_url = jiexi_result.new_url_temp



          //打印日志
          if(window.httplog && error.config){
            window.httplog.push({url:error_url})
          }
          // 是自动取消的请求
          if(axios.isCancel(error) ){
            return Promise.reject(error);
          }

            // 非取消请求,错误时,记录url错误请求次数
            if(http.err_count[error_url])
            {
              // 已经有的进行累加错误次数
              http.err_count[error_url] = http.err_count[error_url]+1;
            } else{
              // 初次错误时设置错误次数为1
              http.err_count[error_url] = 1;
            }
            //暂存 错误上报分析
            http.HTTP_ERROR_API_ERR_DATA.push(error.config)
            if(http.HTTP_ERROR_API_ERR_DATA.length>20)
            {
              http.HTTP_ERROR_API_ERR_DATA.splice(0,http.HTTP_ERROR_API_ERR_DATA.length-20)
            }



          console.log('http.err_count');


          // 总报错次数
          let err_count = Object.values(http.err_count).reduce((a,b)=>a+b)

 let  error_max = compute_error_max()+2;
           console.log("http --错误 -----1----",error_max,err_count,);
             //  错误 超过最大错误次数
           if( err_count>  error_max   ){
            console.log("http --错误 -----2----" );
            console.log("error.config.url--",error.config  );
            console.log("error.config.baseURL----",error.config.baseURL );

            console.log("http --错误 -----3----");
            console.log('发送EMIT_API_DOMAIN_UPD_CMD >>http>>> '+JSON.stringify(error))
            // 接受ws断开命令
             window.vue.$root.$emit('EMIT_API_DOMAIN_UPD_CMD',{type:'http', data:JSON.stringify(error)});

            http.err_count = {};
          }


          // // 设置出现网络中断页面
          // if (window.vue && !window.vue.socket_status && !window.vue.no_network_show) {
          //   window.vue.no_network_show = true;
          // }
          return Promise.reject(error);
        }
      );
    }
  }

  /**
   * @Description:设置网络相关数据
   * @Author success
   * @param:
   * @return:
   * @Date 2020/08/29 16:13:55
   */
  static setApiDomain(){
    let api_domain= window.env.config.domain[window.env.config.current_env][0]
      axios.prototype.HTTP_ROOT_DOMAIN =  api_domain;
      axios.prototype.WS_ROOT_DOMAIN =  api_domain?api_domain.replace("http","ws"):'';
      // if (window.env.NODE_ENV != "development"){
      //   axios.defaults.baseURL = window.env.config.domain[window.env.config.current_env][0];
      // }
      axios.defaults.baseURL =  api_domain;
      if(window.ws && window.ws.setWsUrl) {
        window.ws.setWsUrl(http.getWsUrl());
      }
      http.request_count = 0;
      http.err_count = {};
      // window.ws.retInitData(true)
  }

  /**
   * @Description:获取ws通信地址路径
   * @Author success
   * @param:
   * @return:
   * @Date 2020/05/27 00:12:54
   */
  static getWsUrl(){
    let ws_url = `${axios.prototype.WS_ROOT_DOMAIN}/${window.env.config.api.API_PREFIX_WBSOCKET}/push`;
    return ws_url;
  }

  /**
   * get方法，对应get请求
   * @param {String} url [请求的url地址]
   * @param {Object} params [请求时携带的参数]
   * @param {Object} that [视图对象this]
   * @param {String} key [对象中的key值,在一个this视图中唯一]
   */
  static async get(url, params, that, key, config = {}) {
    if(window.ws && (window.ws.run == false)){
      that = null;
      params = null;
      return;
    }
    return await new Promise((resolve, reject) => {
      if(window.wslog && window.wslog.sendMsg){
        window.wslog.sendMsg('HTTP-S:', { url: url, params: params });
      }
      params = params || {}
      params.rdm = new Date().getTime();
      // 请求的配置对象
      let axios_config = {};
      if(that&&key){
        // 设置当前要求取消的对象集合
        if(!that.cancelRequest)
        {
          that.cancelRequest = {};
        }
        // 绑定取消请求的方法
        that.cancelRequest[key] = function(){
          if(!that.source)
          {
            that.source = {};
          }
          if(typeof that.source[key] === 'function')
          {
            that.source[key]('请求终止')
          }
        }
        // 取消上次的请求
        that.cancelRequest[key]();
        // 设置cancelToken 方法
        axios_config.cancelToken = new axios.CancelToken(function executor(c){
          if(!that.source)
          {
            that.source = {};
          }
          that.source[key] = c;
        })
      }
      // 判断是开盲盒接口就限制10秒未返回就取消请求
      if (url.indexOf('/v1/activity/openLuckyBox1') != -1) {
        clearTimeout(http.openboxTimer)
        http.openboxTimer = setTimeout(() => {
          that && that.cancelRequest['openbox']();
          reject({type: 'openbox_cencel', message: '抽盒失败，请稍后再试'})
        }, 10000);
      }
      let axios_obj = {params: params}
      Object.assign(axios_config, axios_obj, config);
      axios.get(url, axios_config).then(res => {
        if(window.wslog && window.wslog.sendMsg){
          window.wslog.sendMsg('HTTP-R:', res);
        }
        clearTimeout(http.openboxTimer)
        resolve(res);
        that = null;
        params = null;
      }).catch(err => {
        if(window.wslog && window.wslog.sendMsg){
          window.wslog.sendMsg('HTTP-R:', err);
        }
        if(axios.isCancel(err))
        {
          // 请求取消异常
          console.log('Request canceled', err.message)
        } else {
          reject(err)
        }
        that = null;
        params = null;
      })
    });
  }

  /**
   * post方法，对应post请求
   * @param {String} url [请求的url地址]
   * @param {Object} params [请求时携带的参数]
   * @param {Object} that [视图对象this]
   * @param {String} key [对象中的key值,在一个this视图中唯一]
   */
  static async post(url, params, that, key, config = {}, type) {
    if(window.ws && (window.ws.run == false)){
      that = null;
      params = null;
      return;
    }
    return await new Promise((resolve, reject) => {
      if(window.wslog && window.wslog.sendMsg){
        window.wslog.sendMsg('HTTP-S:', { url: url, params: params });
      }
      // 取消请求的设置对象
      let axios_config = {type:type||2};
      if(that&&key){
        // 设置当前要求取消的对象集合
        if(!that.cancelRequest)
        {
          that.cancelRequest = {};
        }
        // 绑定取消请求的方法
        that.cancelRequest[key] = function(){
          if(!that.source)
          {
            that.source = {};
          }
          if(typeof that.source[key] === 'function')
          {
            that.source[key]('请求终止')
          }
        }
        // 取消上次的请求
        that.cancelRequest[key]();
        // 设置cancelToken 方法
        axios_config.cancelToken = new axios.CancelToken(function executor(c){
          if(!that.source)
          {
            that.source = {};
          }
          that.source[key] = c;
        })
      }

      Object.assign(axios_config, config);
      axios.post(url, params, axios_config)
        .then(res => {
          if(window.wslog && window.wslog.sendMsg){
            window.wslog.sendMsg('HTTP-R:', res);
          }
          resolve(res);
          that = null;
          params = null;
        })
        .catch(err => {
          if(window.wslog && window.wslog.sendMsg){
            window.wslog.sendMsg('HTTP-R:', err);
          }
          if(axios.isCancel(err))
          {
            // 请求取消异常
            console.log('Request canceled', err.message)
          } else {
            reject(err)
          }
          that = null;
          params = null;
        })
    });
  }

  /**
   * @description: 检测修正比赛倒计时
   * @param {*}
   * @return {*}
   */
  static fix_mst(res){
    // 判断是否是数组
    let data = _.get(res, 'data.data.data');
    try {
      if(data){
        let mid = 0;
        if(Array.isArray(data)){
          mid = _.get(data, '[0].mid');
          if(mid){
            // 数组处理了
            data.forEach(match => {
              http.match_fix_mst(match, res);
            });
          }
        } else{
          mid = _.get(data, 'mid');
          if(mid){
            // 对象处理了
            http.match_fix_mst(data, res);
          }
        }
      }
    } catch (error) {
      console.error(error)
    }
  }

  /**
   * @description: 修正赛事比赛倒计时
   * @param {*}
   * @return {*}
   */
  static match_fix_mst(match, http_data){
    let time_m = http_data.data.ts_http;
    if(match&&match.ms&&match.mess==1){
      // 对进行中的赛事,并且处于倒计时状态的赛事进行修正
      let csid = parseInt(match.csid);
      let mst = parseInt(match.mst);
      // 转换成秒
      let mm = parseInt(time_m/1000);
      let mmp = parseInt(match.mmp);
      let mmps = "";
      if(mst>0){
        switch (csid) {
          case 1: // 足球
            // 上半场,下半场,加时赛上半场,加时赛下半场
            mmps = [6, 7, 41, 42];
            if(mmps.includes(mmp))
            {
              match.mst = mst+mm;
            }
            break;
          case 4: // 冰球
            // 第一局 第二局 第三局 加时赛 点球大战
            mmps = [1, 2, 3, 40, 50];
            if(mmps.includes(mmp))
            {
              match.mst = mst+mm;
            }
            break;

          case 2: // 篮球
            // 上半场,下半场,第一节,第二节,第三节,第四节,加时赛
            mmps = [1, 2, 13, 14, 15, 16, 40];
            if(mmps.includes(mmp))
            {
              match.mst = mst-mm;
            }
            break;
          case 6: // 美式足球
            // 第一节 第二节 第三节 第四节 加时赛
            mmps = [13, 14, 15, 16, 40];
            if(mmps.includes(mmp))
            {
              match.mst = mst-mm;
            }
            break;

          default:
            break;
        }
        if(match.mst<0){
          match.mst = 0;
        }
        // console.log(`回表--mid:${match.mid}---mmp:${match.mmp}---球种${match.csid}-----前:${mst}---差:${mm}---后:${match.mst}`)
      }
    }
  }
}
export default http;
